
<footer class="py-5 bg-danger">

    <p class="py-5 text-center">text center</p>

</footer>