
<footer class="py-5 bg-danger">

    <p class="py-5 text-center">text center</p>

</footer><?php /**PATH C:\laragon\www\laravel-blade-exo2\resources\views/partials/footer.blade.php ENDPATH**/ ?>