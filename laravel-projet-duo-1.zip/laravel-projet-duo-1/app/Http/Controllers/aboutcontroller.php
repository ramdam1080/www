<?php

namespace App\Http\Controllers;

use App\Models\About;
use Illuminate\Http\Request;

class aboutcontroller extends Controller
{
    public function index( ){
        $about = About::all();
        return view("pages/tbabout",compact("about"));
    }
    //
    public function destroy($id){
        $about = About::find($id);
        $about->delete();
        return redirect()->back();
    }

    public function edit($id){
        $about = About::find($id);
        return view('about-edit', compact('about'));
    }

    public function update($id, Request $request){
        $about = About::find($id);
        $about->image = $request->image;
        $about->nombre1 = $request->nombre1;
        $about->nombre2 = $request->nombre2;
        $about->nombre3 = $request->nombre3;
        $about->pNombre1 = $request->pNombre1;
        $about->pNombre2 = $request->pNombre2;
        $about->pNombre3 = $request->pNombre3;
        $about->p = $request->p;
        $about->save();
        return redirect()->route('about.index');
        // dd($header);
        // return 'Je suis dans update';
    }

    public function show($id){
        $about = About::find($id);
        return view('about-show', compact('about'));
    }
}
