<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use Illuminate\Http\Request;

class bannercontroller extends Controller
{

public function index(){
    $banner = Banner::all();
    return view("pages/tbBanner",compact('banner'));
}

public function destroy($id){
    $banneri = Banner::find($id);
    $banneri->delete();
    return redirect()->back();
}

public function edit($id){
    $banner = Banner::find($id);
    return view('banner-edit', compact('banner'));
}

public function update($id, Request $request){
    $banner = Banner::find($id);
    $banner->h6 = $request->h6;
    $banner->h4 = $request->h4;
    $banner->save();
    return redirect()->route('banner.index');
    // dd($banner);
    // return 'Je suis dans update';
}
public function show($id){
    $banner = Banner::find($id);
    return view('banner-show', compact('banner'));
}
}

