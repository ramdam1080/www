<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;

class contactcontroller extends Controller
{
   public function index(){
      $contact = Contact::all();
      return view("pages/contact",compact("contact"));
   }

   public function destroy($id){
      $contact = Contact::find($id);
      $contact->delete();
      return redirect()->back();
  }
  public function edit($id){
   $contact = Contact::find($id);
   // dd($contact);
   return view("pages/fContact",compact("contact"));

}
public function update($id, Request $request){
     $contact = Contact::find($id);
      $contact->icone = $request->icone;
      $contact->info = $request->info;
      $contact->bouton = $request->button;
      $contact->updated_at = now();
      $contact->save();
      return redirect()->route("contact.index");
  }

  public function show($id){
   $contact = Contact::find($id);
   return view('contact-show', compact('contact'));
}
}
