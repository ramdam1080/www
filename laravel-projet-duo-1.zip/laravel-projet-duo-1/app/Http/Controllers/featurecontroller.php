<?php

namespace App\Http\Controllers;

use App\Models\Feature;
use Illuminate\Http\Request;

class featurecontroller extends Controller

{
    public function index(){

        $feat = Feature::all();
        return view("pages/tbfeature",compact("feat"));
    }
    
    public function destroy($id){
        $feature = Feature::find($id);
        $feature->delete();
        return redirect()->back();
    }

    public function edit($id){
        $feature = Feature::find($id);
        return view('feature-edit', compact('feature'));
    }
    
    public function update($id, Request $request){
        $feature = feature::find($id);
        $feature->h6 = $request->h6;
        $feature->h4 = $request->h4;
        $feature->text = $request->text;
        $feature->pourcent = $request->pourcent;
        $feature->span = $request->span;
        $feature->save();
        return redirect()->route('feature.index');
        // dd($header);
        // return 'Je suis dans update';
    }
    public function show($id){
        $feature = Feature::find($id);
        return view('feature-show', compact('feature'));
    }
}
