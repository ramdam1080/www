<?php

namespace App\Http\Controllers;

use App\Models\Header;
use Illuminate\Http\Request;

class headercontroller extends Controller
{
    //
    public function index(){
        $header= Header::all();
        return view("pages/tbHeader",compact('header'));
    }
    public function destroy($id){
        $headeri = Header::find($id);
        $headeri->delete();
        return redirect()->back();
    }
    public function edit($id){
        $header = Header::find($id);
        return view('header-edit', compact('header'));
    }
    
    public function update($id, Request $request){
        $header = Header::find($id);
        $header->url = $request->url;
        $header->section = $request->section;
        $header->section1 = $request->section1;
        $header->section2 = $request->section2;
        $header->section3 = $request->section3;
        $header->section4 = $request->section4;
        $header->section5 = $request->section5;
        $header->button = $request->button;
        $header->menu = $request->menu;
        $header->save();
        return redirect()->route('header.index');
        // dd($header);
        // return 'Je suis dans update';
    }

    public function show($id){
        $header = Header::find($id);
        return view('header-show', compact('header'));
    }
}
