<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Portfolio;

class portfolioController extends Controller
{
    //
    public function index(){
        $portfolio = Portfolio::all();
        return view("pages/tbPortfolio",compact("portfolio"));
    }
    public function destroy($id){
        $portfolio=Portfolio::find($id);
        $portfolio->delete();
        return redirect()->back();
    }
    public function edit($id){
        $portfolio = Portfolio::find($id);
        return view("pages/fPortfolio",compact("portfolio"));
    }
    public function update($id, Request $request){
        $portfolio = Portfolio::find($id);
        $portfolio->photo1 = $request->photo1; 
        $portfolio->a1 = $request->a1; 
        $portfolio->a11 = $request->a11;
        $portfolio->updated_at = now();
        $portfolio->save();
        return redirect()->route("portfolio.index");
    }

    public function show($id){
        $portfolio = Portfolio::find($id);
        return view('portfolio-show', compact('portfolio'));
    }
}
