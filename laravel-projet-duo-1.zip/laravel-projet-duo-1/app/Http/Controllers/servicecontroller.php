<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;

class servicecontroller extends Controller
{
    //
    public function index(){
        $service = Service::all();
        return view("pages/tbservice",compact("service"));
    }
    public function destroy($id){
        $servicei = Service::find($id);
        $servicei->delete();
        return redirect()->back();
    }
    public function edit($id){
        $servicee = Service::find($id);
        return view("pages/fService",compact("servicee"));
    }
    public function update($id, Request $request){
        $servicee = Service::find($id);
        $servicee->photo = $request->photo;
        $servicee->titre = $request->titre;
        $servicee->description = $request->description;

        $servicee->save();
        return redirect()->route("service.index");
    }

    public function show($id){
        $service = Service::find($id);
        return view('service-show', compact('service'));
    }
}
