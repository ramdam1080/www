<?php

namespace App\Http\Controllers;
use App\Models\About;
use App\Models\Banner;
// use App\Models\Contact;
use App\Models\Feature;
use App\Models\Footer;
use App\Models\Header;
use App\Models\TitreBanner;
use App\Models\Portfolio;
use App\Models\Service;
use App\Models\Contact;
// use App\Models\Footer;
use App\Models\Title;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class welcomeController extends Controller
{
    public function index(){
        $about = About::all();
        $header = Header::all();
        $banner = Banner::all();
        $tbanner = TitreBanner::all();
        $feat = Feature::all();
        $portfolio = Portfolio::all();
        $service = Service::all();
        $contact = Contact::all();
        $title = Title::all();
        $replaceOne = str_replace('(','span',$title);
        $footer = Footer::all();
        $user = User::all();
        $parenthese = ["(",")"];
        $em = ["<em>","</em>"];
        $replace = json_decode(str_replace($parenthese,$em,$title));
        // dd(json_decode($replace));
        return view('welcome', compact('about',"header","banner","tbanner","feat","portfolio","service","contact","title","footer",'user',"replace"));
    }

    public function create(){
        $user2 = User::all();
        return view('/pages/backoffice', compact('user2'));
    }

    // public function destroy($id){
    //     $user = User::find($id);
    //     $user->delete();
    //     return redirect()->back();
    // }

    public function store(Request $request){
        // dd($request);
        $table = new User();
        $table->name = $request->name;
        $table->surname = $request->surname;
        $table->email = $request->email;
        $table->subject = $request->subject;
        $table->message = $request->message;
        $table->save();
        return redirect('/');
    }
}
