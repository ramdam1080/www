<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class About extends Model
{
    use HasFactory;
    protected $table = "about";
    protected $guarded = [
        "image",
        "preTitre",
        "titre",
        "nombre1",
        "nombre2",
        "nombre3",
        "pNombre1",
        "pNombre2",
        "pNombre3",
        "p",
        "bouton"
    ];
}
