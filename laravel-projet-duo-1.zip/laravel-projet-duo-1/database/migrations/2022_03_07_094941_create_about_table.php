<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('about', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('nombre1');
            $table->string('nombre2');
            $table->string('nombre3');
            $table->string('pNombre1');
            $table->string('pNombre2');
            $table->string('pNombre3');
            $table->string('p', 500);
            $table->string('bouton');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('about');
    }
};
