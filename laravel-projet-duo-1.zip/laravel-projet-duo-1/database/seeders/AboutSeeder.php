<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class AboutSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('about') -> insert([
            "image" => "/images/about-left-image.png",
            "nombre1" => "750+",
            "nombre2" => "340+",
            "nombre3" => "128+",
            "pNombre1" => "Projects Finished",
            "pNombre2" => "Happy Clients",
            "pNombre3" => "Awards",
            "p" => "SEO Dream is free digital marketing CSS template provided by TemplateMo website. You are allowed to use this template for your business websites. Please DO NOT redistribute this template ZIP file on any Free CSS collection websites. You may contact us for more information. Thank you.",
            "bouton" => "Discover Company",
        ]);
    }
}
