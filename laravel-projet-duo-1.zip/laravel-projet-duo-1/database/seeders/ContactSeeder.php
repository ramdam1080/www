<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class ContactSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('contact') -> insert([
            "icone" => "/images/contact-icon-01.png",
            "info" => "info@company.com",
            "bouton" => "Send message now"
        ]);
        DB::table('contact') -> insert([
            "icone" => "/images/contact-icon-02.png",
            "info" => "+001-002-0034",
            "bouton" => " "
        ]);
        DB::table('contact') -> insert([
            "icone" => "/images/contact-icon-03.png",
            "info" => "26th Street, Digital Villa",
            "bouton" => " "
        ]);
    }
}
