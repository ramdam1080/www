<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(TitleSeeder::class);
        $this->call(AboutSeeder::class);
        $this->call(HeaderSeeder::class);
        $this->call(BannerSeeder::class);
        $this->call(ContactSeeder::class);
        $this->call(TitreBannerSeeder::class);
        $this->call(FeatureSeeder::class);
        $this->call(ServiceSeeder::class);
        $this->call(PortfolioSeeder::class);
        $this->call(ServiceSeeder::class);
        $this->call(ContactSeeder::class);
        $this->call(TitleSeeder::class);
        $this->call(FooterSeeder::class);
    }
}
