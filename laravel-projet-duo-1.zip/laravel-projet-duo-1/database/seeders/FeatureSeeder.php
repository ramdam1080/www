<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("features")->insert([
            "h6"=>"01",
            "h4"=>"Reach Out",
            "text"=>"This HTML5 template is based on Bootstrap 5 CSS. You are free to customize anything.",
            "pourcent"=>"80%",
            "span"=>"HTML/CSS/JS"
        ]);
        DB::table("features")->insert([
            "h6"=>"02",
            "h4"=>"Develop a Strategy",
            "text"=>"Lorem ipsum dolor sit ameter consectetur adipiscing li elit sed do eiusmod.",
            "pourcent"=>"60%",
            "span"=>"Wordpress"
        ]);
        DB::table("features")->insert([
            "h6"=>"03",
            "h4"=>"Implementation",
            "text"=>"If this template is useful for your website, please consider to If this template is useful for your website, please consider to <a rel='nofollow' href='https://www.paypal.me/templatemo' target='_blank'>support us</a> a little. ",
            "pourcent"=>"90%",
            "span"=>"Marketing"
        ]);
        DB::table("features")->insert([
            "h6"=>"04 ",
            "h4"=>" the result Analyze",
            "text"=>"Below circular progress bar animation supports those CSS values 10, 20, 30, till 100.",
            "pourcent"=>"70%",
            "span"=>"Photoshop"
        ]);
    }
}
