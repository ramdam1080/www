<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class FooterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Db::table('footer')->insert([
            "p1" => "Copyright © 2021 SEO Dream Co., Ltd. All Rights Reserved.",
            "p2" => "Web Designed by "
        ]);
    }
}
