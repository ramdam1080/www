<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class HeaderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("headers")->insert([
            "url" => asset("images/logo-icon.png"),
            "section"=> "Home",
            "section1"=> "Features",
            "section2"=> "About us",
            "section3"=> "Services",
            "section4"=> "Portofolio",
            "section5"=> "Contact Us",
            "button" => "login <i class='fa fa-user' aria-hidden='true'></i>",
            "menu" => "Menu"
        ]);
    }
}
