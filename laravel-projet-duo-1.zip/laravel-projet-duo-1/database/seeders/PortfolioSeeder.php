<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class PortfolioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('portfolios') ->insert([
            "photo1" => "/images/portfolio-01.jpg",
            "a1" => "Awesome Project 101",
            "a11" => "Marketing",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-02.jpg",
            "a1" => "Awesome Project 102",
            "a11" => "Branding",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-03.jpg",
            "a1" => "Awesome Project 103",
            "a11" => "Consulting",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-04.jpg",
            "a1" => "Awesome Project 104",
            "a11" => "Artwork",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-05.jpg",
            "a1" => "Awesome Project 105",
            "a11" => "Branding",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-01.jpg",
            "a1" => "Awesome Project 106",
            "a11" => "Artwork",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-02.jpg",
            "a1" => "Awesome Project 107",
            "a11" => "Creative",
        ]);
        DB::table('portfolios') -> insert([
            "photo1" => "/images/portfolio-03.jpg",
            "a1" => "Awesome Project 108",
            "a11" => "Consulting",
        ]);
    }
}
