<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class TitleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('titles') ->insert([
            "soustitre" => "ABOUT US",
            "titre" => "Top ",
            "titre2" => " (Marketing)",
            "titre3" => " Agency & Consult Your WebSite",
            "titre4" => " With Us"
        ]);
        DB::table('titles') ->insert([
            "soustitre" => "OUR SERVICES",
            "titre" => "Discover What We Do &",
            "titre2" => " Offer",
            "titre3" => " To Our",
            "titre4" => " Clients"
        ]);
        DB::table('titles') ->insert([
            "soustitre" => "OUR PORTOFOLIO",
            "titre" => "Discover Our Recent",
            "titre2" => " Projects",
            "titre3" => " And",
            "titre4" => " Showcases"
        ]);
        DB::table('titles') ->insert([
            "soustitre" => "(CONTACT) US",
            "titre" => "Fill Out The Form Below To Get In Touch With Us",
            "titre2" => "",
            "titre3" => "",
            "titre4" => ""
        ]);
    }
}
