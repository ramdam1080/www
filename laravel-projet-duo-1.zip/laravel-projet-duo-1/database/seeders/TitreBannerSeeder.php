<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TitreBannerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("titre_banners")->insert([
            "h2"=> "Digital Maketing Agency",
            "seo"=>"SEO &",
            "button"=>"Get Your Quote"
        ]);
    }
}
