<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <title>Document</title>
</head>

<body>
    <h1>Bienvenue sur ma page Edit</h1>
    <form action="{{ route('about-update', $about->id) }}" method="post">
        @csrf
        <div class="d-flex flex-column">
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Url</label>
                <input value="{{ $about->image }}" type="text" name="image">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section</label>
                <input value="{{ $about->nombre1 }}" type="text" name="nombre1">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section1</label>
                <input value="{{ $about->nombre2 }}" type="text" name="nombre2">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section2</label>
                <input value="{{ $about->nombre3 }}" type="text" name="nombre3">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section3</label>
                <input value="{{ $about->pNombre1 }}" type="text" name="pNombre1">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section4</label>
                <input value="{{ $about->pNombre2 }}" type="text" name="pNombre2">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section5</label>
                <input value="{{ $about->pNombre3 }}" type="text" name="pNombre3">
            </div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Button</label>
                <input value="{{ $about->p }}" type="text" name="p">
            </div>
        </div>
        <button class="mt-3" type="submit">update</button>
    </form>
    <script src="{{ asset('js/app.js') }}"></script>
</body>

</html>
