<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset("css/app.css") }}">
    <title>Document</title>
</head>


<body>
    <h1>Je suis dans la page Edit</h1>
    <form action="{{ route('banner-update', $banner->id) }}" method="post">
        @csrf
        <label for="">Petit Titre</label>
        <input value="{{ $banner->h6 }}" type="text" name="h6">
        <label for="">Titre</label>
        <input value="{{ $banner->h4 }}" type="text" name="h4">
        <button type="submit">update</button>
    </form>
    <script src="{{ asset("js/app.js") }}"></script>
</body>

</html>
