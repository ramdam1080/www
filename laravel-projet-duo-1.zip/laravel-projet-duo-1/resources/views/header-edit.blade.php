<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset("css/app.css") }}">
    <title>Document</title>
</head>


<body class="p-5">
    <h1 class="mb-3">Je suis dans la page Edit</h1>
    {{-- <form action="/banner-update/{{ $header->id }}" method="post"> --}}
    <form action="{{ route('header-update', $header->id) }}" method="post">
        @csrf
        <div class="d-flex flex-column">
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Url</label>
                <input value="{{ $header->url }}" type="text" name="url"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section</label>
                <input value="{{ $header->section }}" type="text" name="section"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section1</label>
                <input value="{{ $header->section1 }}" type="text" name="section1"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section2</label>
                <input value="{{ $header->section2 }}" type="text" name="section2"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section3</label>
                <input value="{{ $header->section3 }}" type="text" name="section3"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section4</label>
                <input value="{{ $header->section4 }}" type="text" name="section4"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section5</label>
                <input value="{{ $header->section5 }}" type="text" name="section5"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Button</label>
                <input value="{{ $header->button }}" type="text" name="button"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Menu</label>
                <input value="{{ $header->menu }}" type="text" name="menu"></div>
        </div>
        <button class="mt-3" type="submit">update</button>
    </form>
    <script src="{{ asset("js/app.js") }}"></script>
</body>
</html>