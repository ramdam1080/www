@extends('layouts/app')

@section('content')
    
<form action="{{ route("portfolio.update",$portfolio->id) }}" method="POST">
    @csrf
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">photo1</label>
      <input type="text"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="photo1" value="{{ $portfolio->photo1 }}">
      <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">a1</label>
      <input name="a1" type="text" class="form-control"   id="exampleInputPassword1" value="{{ $portfolio->a1 }}">
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">button</label>
      <input type="text" name="a11" class="form-control" id="exampleInputPassword1" value="{{  $portfolio->a11 }}">
    </div>
    {{-- <div class="mb-3 form-check">
      <input type="checkbox" class="form-check-input" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Check me out</label>
    </div> --}}
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
@endsection