@extends('layouts/appnav')

@section('content')
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">CodingLab</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list p-0">
            <li>
                <a href="#">
                    <i class='bx bx-grid-alt'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
            <li>
                <a href="/tbHeader">
                    <i class='bx bx-user'> </i>
                    <span class="links_name">Header</span>
                </a>
                <span class="tooltip">Header</span>
            </li>
            <li>
                <a href="/tbBanner">
                    <i class='bx bx-chat'></i>
                    <span class="links_name">Banner</span>
                </a>
                <span class="tooltip">Banner</span>
            </li>
            <li>
                <a href="/tbfeature">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Features</span>
                </a>
                <span class="tooltip">Features</span>
            </li>
            <li>
                <a href="/tbservice">
                    <i class='bx bx-folder'></i>
                    <span class="links_name">Services</span>
                </a>
                <span class="tooltip">Services</span>
            </li>
            <li>
                <a href="/tbabout">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">About</span>
                </a>
                <span class="tooltip">About</span>
            </li>
            <li>
                <a href="/tbportfolio">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Portfolios</span>
                </a>
                <span class="tooltip">Portfolios</span>
            </li>
            <li>
                <a href="/tbcontact">
                    <i class='bx bx-heart'></i>
                    <span class="links_name">Contact</span>
                </a>
                <span class="tooltip">Contact</span>
            </li>
            <li>
                <a href="/">
                    <i class='bx bx-cog'></i>
                    <span class="links_name">Home</span>
                </a>
                <span class="tooltip">Home</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <!--<img src="profile.jpg" alt="profileImg">-->
                    <div class="name_job">
                        <div class="name">Prem Shahi</div>
                        <div class="job">Web designer</div>
                    </div>
                </div>
                <i class='bx bx-log-out' id="log_out"></i>
            </li>
        </ul>
    </div>
    <section class="home-section">
        <div class="">
            <h1>Dashboard</h1>
            <div class="p-5">
                <table class="table table-warning table-bordered table-striped table-hover text-center">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Petit titre</th>
                            <th scope="col">Moyen titre</th>
                            <th scope="col">Action 1</th>
                            <th scope="col">Action 2</th>
                            <th scope="col">Action 3</th>

                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($banner as $item)
                            <tr>
                                <th scope="row">{{ $item->id }}</th>
                                <td>{{ $item->h6 }}</td>
                                <td>{{ $item->h4 }}</td>
                                <td>
                                    <form action="{{ route('banner.destroy', $item->id) }}" method="post">
                                        @csrf
                                        <button type="submit" class="px-2 py-1 bg-danger text-white">delete</button>
                                    </form>

                                </td>
                                <td><a href="/banner-edit/{{ $item->id }}">Edit</a></td>
                                <td class="text-center"><a href="{{ route('banner.show', $item->id) }}">Show :
                                        {{ $item->id }}</a></td>

                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
        <div class="p-5">
        </div>
    </section>

    <script>
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");
        let searchBtn = document.querySelector(".bx-search");

        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        // following are the code to change sidebar button(optional)
        function menuBtnChange() {
            if (sidebar.classList.contains("open")) {
                closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
            } else {
                closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
            }
        }
    </script>
@endsection
