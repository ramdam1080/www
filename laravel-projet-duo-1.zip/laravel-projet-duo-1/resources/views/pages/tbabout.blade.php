@extends('layouts/appnav')

@section('content')
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">CodingLab</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list p-0">
            <li>
                <a href="#">
                    <i class='bx bx-grid-alt'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
            <li>
                <a href="/tbHeader">
                    <i class='bx bx-user'> </i>
                    <span class="links_name">Header</span>
                </a>
                <span class="tooltip">Header</span>
            </li>
            <li>
                <a href="/tbBanner">
                    <i class='bx bx-chat'></i>
                    <span class="links_name">Banner</span>
                </a>
                <span class="tooltip">Banner</span>
            </li>
            <li>
                <a href="/tbfeature">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Features</span>
                </a>
                <span class="tooltip">Features</span>
            </li>
            <li>
                <a href="/tbservice">
                    <i class='bx bx-folder'></i>
                    <span class="links_name">Services</span>
                </a>
                <span class="tooltip">Services</span>
            </li>
            <li>
                <a href="/tbabout">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">About</span>
                </a>
                <span class="tooltip">About</span>
            </li>
            <li>
                <a href="/tbportfolio">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Portfolios</span>
                </a>
                <span class="tooltip">Portfolios</span>
            </li>
            <li>
                <a href="/tbcontact">
                    <i class='bx bx-heart'></i>
                    <span class="links_name">Contact</span>
                </a>
                <span class="tooltip">Contact</span>
            </li>
            <li>
                <a href="/">
                    <i class='bx bx-cog'></i>
                    <span class="links_name">Home</span>
                </a>
                <span class="tooltip">Home</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <!--<img src="profile.jpg" alt="profileImg">-->
                    <div class="name_job">
                        <div class="name">Prem Shahi</div>
                        <div class="job">Web designer</div>
                    </div>
                </div>
                <i class='bx bx-log-out' id="log_out"></i>
            </li>
        </ul>
    </div>
    <section class="home-section p-2">
        <div class="">
            <h1>Dashboard</h1>
            <div class="p-3">
                <table class="table table-warning table-bordered text-center table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Image</th>
                            <th scope="col">Nombre 1</th>
                            <th scope="col">Nombre 2</th>
                            <th scope="col">Nombre 3</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($about as $item)
                            <tr>
                                <th scope="row">{{ $item->id }}</th>
                                <td>{{ $item->image }}</td>
                                <td>{{ $item->nombre1 }}</td>
                                <td>{{ $item->nombre2 }}</td>
                                <td>{{ $item->nombre3 }}</td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>

                <table class="table table-warning table-bordered text-center table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Paragraphe du Nombre 1</th>
                            <th scope="col">Paragraphe du Nombre 2</th>
                            <th scope="col">Paragraphe du Nombre 3</th>
                            <th scope="col-3">Paragraphe</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($about as $item)
                            <tr>
                                <td>{{ $item->pNombre1 }}</td>
                                <td>{{ $item->pNombre2 }}</td>
                                <td>{{ $item->pNombre3 }}</td>
                                <td>{{ $item->p }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <table class="table table-warning table-bordered text-center table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Action</th>
                            <th scope="col">Action 2</th>
                            <th scope="col">Action 3</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <form action="{{ route('about.destroy', $item->id) }}" method="post">
                                    @csrf
                                    <button class="py-1 px-2 text-white bg-danger" tpe="submit">Delete</button>
                                </form>
                            </td>
                            <td><a href="/about-edit/{{ $item->id }}">Edit</a></td>
                            <td class="text-center"><a href="{{ route('about.show', $item->id) }}">Show :
                                    {{ $item->id }}</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <script>
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");
        let searchBtn = document.querySelector(".bx-search");

        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        // following are the code to change sidebar button(optional)
        function menuBtnChange() {
            if (sidebar.classList.contains("open")) {
                closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
            } else {
                closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
            }
        }
    </script>
@endsection
