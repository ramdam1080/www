<div id="about" class="about-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
            <img src="{{ asset($about[0]->image) }}" alt="">
          </div>
        </div>
        <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
          <div class="section-heading">
            <h6>{{ $title[0]->soustitre }}</h6>
            <h2>{{ $title[0]->titre }} {!! $replace[0]->titre2 !!}{{ $title[0]->titre3 }}<span>{{ $title[0]->titre4 }}</span></h2>
          </div>
          <div class="row">
            <div class="col-lg-4 col-sm-4">
              <div class="about-item">
                <h4>{{ $about[0]->nombre1 }}</h4>
                <h6>{{ $about[0]->pNombre1 }}</h6>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4">
              <div class="about-item">
                <h4>{{ $about[0]->nombre2 }}</h4>
                <h6>{{ $about[0]->pNombre2 }}</h6>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4">
              <div class="about-item">
                <h4>{{ $about[0]->pNombre3 }}</h4>
                <h6>{{ $about[0]->pNombre3 }}</h6>
              </div>
            </div>
          </div>
          <p><a rel="nofollow" href="https://templatemo.com/tm-563-seo-dream" target="_parent">SEO Dream</a> is free digital marketing CSS template provided by TemplateMo website. You are allowed to use this template for your business websites. Please DO NOT redistribute this template ZIP file on any Free CSS collection websites. You may contact us for more information. Thank you.</p>
          <div class="main-green-button"><a href="#">Discover company</a></div>
        </div>
      </div>
    </div>
  </div>