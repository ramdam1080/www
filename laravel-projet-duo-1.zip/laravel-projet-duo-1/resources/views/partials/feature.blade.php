  <div id="features" class="features section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="features-content">
            <div class="row">
              @foreach ($feat->shuffle() as $item)
              <div class="col-lg-3">
                @if ($item === $feat[0])
                    
                <div class="features-item first-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
                  <div class="first-number number">
                    @endif
                    @if ($item === $feat[1])
                    
                    <div class="features-item second-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
                  <div class="second-number number">
                    @endif
                    @if ($item === $feat[2])
                    
                    <div class="features-item first-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                  <div class="third-number number">
                    @endif
                    @if ($item === $feat[3])
                    
                    <div class="features-item second-feature last-features-item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.6s">
                  <div class="fourth-number number">
                @endif
                    <h6>{{$item->h6 }}</h6>
                  </div>
                  <div class="icon"></div>
                  <h4>{{$item->h4 }}</h4>
                  <div class="line-dec"></div>
                  <p>{!! $item->text !!}</p>
                </div>
              </div>
              @endforeach
              {{-- <div class="col-lg-3">
                <div class="features-item second-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
                  <div class="second-number number">
                    <h6>{{$feat[1]->h6  }}</h6>
                  </div>
                  <div class="icon"></div>
                  <h4>{{$feat[1]->h4  }}</h4>
                  <div class="line-dec"></div>
                  <p>{{$feat[1]->text  }}</p>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="features-item first-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                  <div class="third-number number">
                    <h6>{{$feat[2]->h6  }}</h6>
                  </div>
                  <div class="icon"></div>
                  <h4>{{$feat[2]->h4 }}</h4>
                  <div class="line-dec"></div>
                  <p>{{$feat[2]->text  }} <a rel="nofollow" href="https://www.paypal.me/templatemo" target="_blank">support us</a> a little.</p>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="features-item second-feature last-features-item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.6s">
                  <div class="fourth-number number">
                    <h6>{{$feat[3]->h6  }}</h6>
                  </div>
                  <div class="icon"></div>
                  <h4>{{$feat[3]->h4  }}</h4>
                  <div class="line-dec"></div>
                  <p>{{$feat[3]->text  }}</p>
                </div>
              </div> --}}
            </div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="skills-content">
            <div class="row">
              <div class="col-lg-3">
                <div class="skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                  <div class="progress" data-percentage="80">
                    <span class="progress-left">
                      <span class="progress-bar"></span>
                    </span>
                    <span class="progress-right">
                      <span class="progress-bar"></span>
                    </span>
                    <div class="progress-value">
                      <div>
                        {{$feat[0]->pourcent  }}<br>
                        <span>{{$feat[0]->span  }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0.2s">
                  <div class="progress" data-percentage="60">
                    <span class="progress-left">
                      <span class="progress-bar"></span>
                    </span>
                    <span class="progress-right">
                      <span class="progress-bar"></span>
                    </span>
                    <div class="progress-value">
                      <div>
                        {{$feat[1]->pourcent  }}<br>
                        <span>{{$feat[1]->span  }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0.4s">
                  <div class="progress" data-percentage="90">
                    <span class="progress-left">
                      <span class="progress-bar"></span>
                    </span>
                    <span class="progress-right">
                      <span class="progress-bar"></span>
                    </span>
                    <div class="progress-value">
                      <div>
                        {{$feat[2]->pourcent  }}<br>
                        <span>{{$feat[2]->span  }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="skill-item last-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0.6s">
                  <div class="progress" data-percentage="70">
                    <span class="progress-left">
                      <span class="progress-bar"></span>
                    </span>
                    <span class="progress-right">
                      <span class="progress-bar"></span>
                    </span>
                    <div class="progress-value">
                      <div>
                        {{$feat[3]->pourcent  }}<br>
                        <span>{{$feat[3]->span  }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>