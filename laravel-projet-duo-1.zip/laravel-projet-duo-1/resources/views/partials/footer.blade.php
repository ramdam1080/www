<footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>{{ $footer[0]->p1 }}
          
          <br>{{ $footer[0]->p2 }} <a rel="nofollow" href="https://templatemo.com" title="free CSS templates">TemplateMo</a></p>
        </div>
      </div>
    </div>
  </footer>