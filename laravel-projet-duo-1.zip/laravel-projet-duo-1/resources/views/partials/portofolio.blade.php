<div id="portfolio" class="our-portfolio section">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="section-heading wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <h6>{{ $title[2]->soustitre }}</h6>
            <h2>{{ $title[2]->titre }}<em>{{ $title[2]->titre2 }}</em>{{ $title[2]->titre3 }}<span>{{ $title[2]->titre4 }}</span></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
      <div class="row">
        <div class="col-lg-12">
          <div class="loop owl-carousel">
            <div class="item">
              {{-- @foreach($portfolio as $item) --}}
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[0]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[0]->a1 }}</h4></a>
                      <span>{{ $portfolio[0]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
              {{-- @endforeach --}}
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[1]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[1]->a1 }}</h4></a>
                      <span>{{ $portfolio[1]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[0]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[0]->a1 }}</h4></a>
                      <span>{{ $portfolio[0]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[1]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[1]->a1 }}</h4></a>
                      <span>{{ $portfolio[1]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[2]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[2]->a1 }}</h4></a>
                      <span>{{ $portfolio[2]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[3]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[3]->a1 }}</h4></a>
                      <span>{{ $portfolio[3]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[4]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[4]->a1 }}</h4></a>
                      <span>{{ $portfolio[4]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[5]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[5]->a1 }}</h4></a>
                      <span>{{ $portfolio[5]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[6]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[6]->a1 }}</h4></a>
                      <span>{{ $portfolio[6]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="{{ asset($portfolio[7]->photo1) }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>{{ $portfolio[7]->a1 }}</h4></a>
                      <span>{{ $portfolio[7]->a11 }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
