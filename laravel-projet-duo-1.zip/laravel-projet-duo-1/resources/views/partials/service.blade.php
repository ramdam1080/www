<div id="services" class="our-services section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="section-heading wow bounceIn" data-wow-duration="1s" data-wow-delay="0.2s">
                    <h6>{{ $title[1]->soustitre }}</h6>
                    <h2>{{ $title[1]->titre }}<span>{{ $title[1]->titre2 }}</span>{{ $title[1]->titre3 }}<em>{{ $title[1]->titre4 }}</em>
                    </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            @foreach ( $service->shuffle()->take(6) as $item)
                <div class="col-lg-4">
                    <div class="service-item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.3s">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="icon">
                                    <img src="{{ asset($item->photo) }}" alt="">
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="right-content">
                                    <h4>{{ $item->titre }}</h4>
                                    <p>{{ $item->description }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
</div>
</div>
</div>
