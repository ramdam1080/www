@extends('layouts/app')

@section('content')
    @include('partials/preloader')

    @include('partials/header')
    @include('partials/banner')
    @include('partials/feature')
    @include('partials/about')
    @include('partials/service')
    @include('partials/portofolio')
    @include('partials/contact')
    @include('partials/footer')

@endsection
    

