<?php

use App\Http\Controllers\bannercontroller;
use App\Http\Controllers\featurecontroller;
use App\Http\Controllers\headercontroller;
use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\AboutController;
use App\Http\Controllers\welcomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\contactcontroller;
use App\Http\Controllers\portfolioController;
use App\Http\Controllers\servicecontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [welcomeController::class, 'index']);
// Route::get('/tbfeature', [featurecontroller::class, 'index']);
// Route::get('/tbabout', [AboutController::class, 'index']);
// Route::get('/tbcontact', [contactController::class, 'index']);
Route::get('/pages/backoffice', [welcomeController::class, 'create']);
Route::post('/store/user', [welcomeController::class, 'store']);

Route::get('/tbBanner', [bannercontroller::class, 'index'])->name('banner.index');
Route::post('/back/banner/{id}/delete',[bannercontroller::class,"destroy"])->name("banner.destroy");
Route::get('/banner-edit/{id}', [bannercontroller::class, 'edit'])->name("banner.edit");
Route::post('/banner-update/{id}', [bannercontroller::class, 'update'])->name('banner-update');
Route::get('/back/banner/{id}/show/', [bannercontroller::class, 'show'])->name('banner.show');


Route::get('/tbHeader', [headercontroller::class, 'index'])->name('header.index');
Route::post("/back/header/{id}/delete",[headercontroller::class,"destroy"])->name("header.destroy");
Route::get('/header-edit/{id}', [headercontroller::class, 'edit'])->name("header.edit");
Route::post('/header-update/{id}', [headercontroller::class, 'update'])->name('header-update');
Route::get('/back/header/{id}/show/', [headercontroller::class, 'show'])->name('header.show');


Route::get('/tbservice', [servicecontroller::class, 'index'])->name("service.index");
Route::post("/back/service/{id}/delete",[servicecontroller::class,"destroy"])->name("service.destroy");
Route::get('pages/fService{id}',[servicecontroller::class,"edit"])->name("form.edit");
Route::post('pages/fService/update{id}',[servicecontroller::class,"update"])->name("form.update");
Route::get('/back/service/{id}/show/', [servicecontroller::class, 'show'])->name('service.show');

// Route::get('/back/users', [welcomeController::class, 'index'])->name('users_index');
// Route::post('/back/user/{id}/delete',[welcomeController::class, 'destroy'])->name('users.destroy');

Route::get('/tbabout', [aboutcontroller::class, 'index'])->name("about.index");
Route::post("/back/about/{id}/delete",[aboutcontroller::class,"destroy"])->name("about.destroy");
Route::get('/about-edit/{id}', [aboutcontroller::class, 'edit'])->name("about.edit");
Route::post('/about-update/{id}', [aboutcontroller::class, 'update'])->name('about-update');
Route::get('/back/about/{id}/show/', [aboutcontroller::class, 'show'])->name('about.show');


Route::get('/tbcontact', [contactcontroller::class, 'index'])->name("contact.index");
Route::post("/back/contact/{id}/delete",[contactcontroller::class,"destroy"])->name("contact.destroy");
Route::get("pages/fcontact/edit/{id}",[contactcontroller::class,"edit"])->name("contact.edit");
Route::post("pages/fcontact/update/{id}",[contactcontroller::class,"update"])->name("contact.update");
Route::get('/back/contact/{id}/show/', [contactcontroller::class, 'show'])->name('contact.show');



// Route::get('/back/users', [welcomeController::class, 'index'])->name('users_index');
// Route::post('/back/user/{id}/delete',[welcomeController::class, 'destroy'])->name('users.destroy');

Route::get('/tbfeature', [featureController::class, 'index'])->name('feature.index');
Route::post('/back/feature/{id}/delete',[featureController::class, 'destroy'])->name('feature.destroy');
Route::get('/feature-edit/{id}', [featureController::class, 'edit'])->name("feature.edit");
Route::post('/feature-update/{id}', [featureController::class, 'update'])->name('feature-update');

Route::get('/tbportfolio',[portfolioController::class,"index"])->name("portfolio.index");
Route::post('/tbportfolio/destroy/{id}',[portfolioController::class,"destroy"])->name("portfolio.destroy");
Route::get('/pages/fportfolio/edit/{id}',[portfolioController::class,"edit"])->name("portfolio.edit");
Route::post('/tbportfolio/update/{id}',[portfolioController::class,"update"])->name("portfolio.update");
Route::get('/back/feature/{id}/show/', [featureController::class, 'show'])->name('feature.show');
