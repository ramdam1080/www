<div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="left-content header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <div class="row">
                  <div class="col-lg-4 col-sm-4">
                    <div class="info-stat">
                      <h6><?php echo e($banner[0]->h6); ?></h6>
                      <h4><?php echo e($banner[0]->h4); ?></h4>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="info-stat">
                      <h6><?php echo e($banner[1]->h6); ?></h6>
                      <h4><?php echo e($banner[1]->h4); ?></h4>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="info-stat">
                      <h6><?php echo e($banner[2]->h6); ?></h6>
                      <h4><?php echo e($banner[2]->h4); ?></h4>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <h2><?php echo e($tbanner[0]->seo); ?> &amp; <?php echo e($tbanner[0]->h2); ?></h2>
                  </div>
                  <div class="col-lg-12">
                    <div class="main-green-button scroll-to-section">
                      <a href="/pages/backoffice"><?php echo e($tbanner[0]->button); ?></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="<?php echo e(asset("images/banner-right-image.png")); ?>" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/banner.blade.php ENDPATH**/ ?>