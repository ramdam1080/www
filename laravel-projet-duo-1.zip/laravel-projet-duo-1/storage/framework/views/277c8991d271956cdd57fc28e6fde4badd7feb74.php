<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset("css/bootstrap.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/bootstrap.min.css.map")); ?>" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/templatemo-seo-dream.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/animated.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/owl.css')); ?>">
    <title>Document</title>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl-carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/animation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/imagesloaded.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/layouts/app.blade.php ENDPATH**/ ?>