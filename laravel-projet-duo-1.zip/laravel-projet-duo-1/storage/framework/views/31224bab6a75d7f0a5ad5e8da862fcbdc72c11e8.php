

<?php $__env->startSection('content'); ?>
    
<form action="<?php echo e(route("portfolio.update",$portfolio->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">photo1</label>
      <input type="text"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="photo1" value="<?php echo e($portfolio->photo1); ?>">
      <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">a1</label>
      <input name="a1" type="text" class="form-control"   id="exampleInputPassword1" value="<?php echo e($portfolio->a1); ?>">
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">button</label>
      <input type="text" name="a11" class="form-control" id="exampleInputPassword1" value="<?php echo e($portfolio->a11); ?>">
    </div>
    
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/pages/fPortfolio.blade.php ENDPATH**/ ?>