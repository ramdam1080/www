

<?php $__env->startSection('content'); ?>
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">CodingLab</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list p-0">
            <li>
                <a href="#">
                    <i class='bx bx-grid-alt'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
            <li>
                <a href="/tbHeader">
                    <i class='bx bx-user'> </i>
                    <span class="links_name">Header</span>
                </a>
                <span class="tooltip">Header</span>
            </li>
            <li>
                <a href="/tbBanner">
                    <i class='bx bx-chat'></i>
                    <span class="links_name">Banner</span>
                </a>
                <span class="tooltip">Banner</span>
            </li>
            <li>
                <a href="/tbfeature">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Features</span>
                </a>
                <span class="tooltip">Features</span>
            </li>
            <li>
                <a href="/tbservice">
                    <i class='bx bx-folder'></i>
                    <span class="links_name">Services</span>
                </a>
                <span class="tooltip">Services</span>
            </li>
            <li>
                <a href="/tbabout">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">About</span>
                </a>
                <span class="tooltip">About</span>
            </li>
            <li>
                <a href="/tbportfolio">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Portfolios</span>
                </a>
                <span class="tooltip">Portfolios</span>
            </li>
            <li>
                <a href="/tbcontact">
                    <i class='bx bx-heart'></i>
                    <span class="links_name">Contact</span>
                </a>
                <span class="tooltip">Contact</span>
            </li>
            <li>
                <a href="/">
                    <i class='bx bx-cog'></i>
                    <span class="links_name">Home</span>
                </a>
                <span class="tooltip">Home</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <!--<img src="profile.jpg" alt="profileImg">-->
                    <div class="name_job">
                        <div class="name">Prem Shahi</div>
                        <div class="job">Web designer</div>
                    </div>
                </div>
                <i class='bx bx-log-out' id="log_out"></i>
            </li>
        </ul>
    </div>
    <section class="home-section">
        <div class="">
            <h1>Dashboard</h1>
            <div class="p-3">
                <table class="table table-warning table-bordered text-center table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Description</th>
                            <th scope="col">Action 1</th>
                            <th scope="col">Action 2</th>
                            <th scope="col">Action 3</th>
                            

                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->description); ?></td>
                                <td><form action="<?php echo e(route('service.destroy', $item->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <button type="submit" class="px-2 py-1 text-white bg-danger">Delete</button>
                              </form></td>
                                <td><form action="<?php echo e(route('service.destroy', $item->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <a href="<?php echo e(route('form.edit', $item->id)); ?>" class="">Edit</a>
                              </form></td>
                              <td class="text-center"><a href="<?php echo e(route('service.show', $item->id)); ?>">Show : <?php echo e($item->id); ?></a></td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <script>
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");
        let searchBtn = document.querySelector(".bx-search");

        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
            sidebar.classList.toggle("open");
            menuBtnChange(); //calling the function(optional)
        });

        // following are the code to change sidebar button(optional)
        function menuBtnChange() {
            if (sidebar.classList.contains("open")) {
                closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
            } else {
                closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/pages/tbservice.blade.php ENDPATH**/ ?>