<div id="portfolio" class="our-portfolio section">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="section-heading wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <h6><?php echo e($title[2]->soustitre); ?></h6>
            <h2><?php echo e($title[2]->titre); ?><em><?php echo e($title[2]->titre2); ?></em><?php echo e($title[2]->titre3); ?><span><?php echo e($title[2]->titre4); ?></span></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
      <div class="row">
        <div class="col-lg-12">
          <div class="loop owl-carousel">
            <div class="item">
              
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[0]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[0]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[0]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[1]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[1]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[1]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[0]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[0]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[0]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[1]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[1]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[1]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[2]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[2]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[2]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[3]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[3]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[3]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[4]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[4]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[4]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[5]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[5]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[5]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[6]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[6]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[6]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                  <img src="<?php echo e(asset($portfolio[7]->photo1)); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4><?php echo e($portfolio[7]->a1); ?></h4></a>
                      <span><?php echo e($portfolio[7]->a11); ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/portofolio.blade.php ENDPATH**/ ?>