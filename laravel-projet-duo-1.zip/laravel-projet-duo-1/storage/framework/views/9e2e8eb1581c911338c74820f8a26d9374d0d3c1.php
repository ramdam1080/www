<div id="services" class="our-services section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="section-heading wow bounceIn" data-wow-duration="1s" data-wow-delay="0.2s">
                    <h6><?php echo e($title[1]->soustitre); ?></h6>
                    <h2><?php echo e($title[1]->titre); ?><span><?php echo e($title[1]->titre2); ?></span><?php echo e($title[1]->titre3); ?><em><?php echo e($title[1]->titre4); ?></em>
                    </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <?php $__currentLoopData = $service->shuffle()->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="service-item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.3s">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="icon">
                                    <img src="<?php echo e(asset($item->photo)); ?>" alt="">
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="right-content">
                                    <h4><?php echo e($item->titre); ?></h4>
                                    <p><?php echo e($item->description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/service.blade.php ENDPATH**/ ?>