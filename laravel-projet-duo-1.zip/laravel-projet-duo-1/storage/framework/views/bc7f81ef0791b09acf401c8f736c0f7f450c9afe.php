<header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.html" class="logo">
              <h4>SEO Dream <img src="<?php echo e($header[0]->url); ?>" alt=""></h4>
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active"><?php echo e($header[0]->section); ?></a></li>
              <li class="scroll-to-section"><a href="#features"><?php echo e($header[0]->section1); ?></a></li>
              <li class="scroll-to-section"><a href="#about"><?php echo e($header[0]->section2); ?></a></li>
              <li class="scroll-to-section"><a href="#services"><?php echo e($header[0]->section3); ?></a></li>
              <li class="scroll-to-section"><a href="#portfolio"><?php echo e($header[0]->section4); ?></a></li>
              <li class="scroll-to-section"><a href="#contact"><?php echo e($header[0]->section5); ?></a></li> 
              <li class="scroll-to-section"><div class="main-blue-button"><a href="/pages/backoffice"><?php echo $header[0]->button; ?>  </a> </div></li> 
              
            </ul>        
            <a class='menu-trigger'>
                <span><?php echo e($header[0]->menu); ?></span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** --><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/header.blade.php ENDPATH**/ ?>