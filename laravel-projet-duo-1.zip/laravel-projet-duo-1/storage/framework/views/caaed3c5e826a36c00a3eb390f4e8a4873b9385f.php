<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
    <title>Document</title>
</head>


<body>
    <h1 class="mb-3">Je suis dans la page Edit</h1>
    
    <form action="<?php echo e(route('feature-update', $feature->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="d-flex flex-column">
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Url</label>
                <input value="<?php echo e($feature->h6); ?>" type="text" name="h6"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section</label>
                <input value="<?php echo e($feature->h4); ?>" type="text" name="h4"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section1</label>
                <input value="<?php echo e($feature->text); ?>" type="text" name="text"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section2</label>
                <input value="<?php echo e($feature->pourcent); ?>" type="text" name="pourcent"></div>
            <div class="d-flex my-1"><label class="mx-5 my-2" for="">Section3</label>
                <input value="<?php echo e($feature->span); ?>" type="text" name="span"></div>
        </div>
        <button class="mt-3" type="submit">update</button>
    </form>
    <script src="<?php echo e(asset("js/app.js")); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/feature-edit.blade.php ENDPATH**/ ?>