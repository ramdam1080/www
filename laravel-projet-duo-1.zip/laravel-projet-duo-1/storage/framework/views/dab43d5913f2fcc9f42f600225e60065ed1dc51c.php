<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title>Document</title>
</head>


<body>
    <h1>Bienvenue sur ma page Show</h1>
    <p><?php echo e($service); ?></p>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/service-show.blade.php ENDPATH**/ ?>